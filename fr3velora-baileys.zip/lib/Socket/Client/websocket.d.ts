import { AbstractSocketClient } from './types.js';
export declare class WebSocketClient extends AbstractSocketClient {
    socket: any;
    constructor();
    get isOpen(): boolean;
    get isClosed(): boolean;
    get isClosing(): boolean;
    get isConnecting(): boolean;
    connect(): void;
    close(): Promise<void>;
    send(str: any, cb: any): boolean;
}
